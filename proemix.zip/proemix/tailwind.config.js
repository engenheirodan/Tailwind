/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

